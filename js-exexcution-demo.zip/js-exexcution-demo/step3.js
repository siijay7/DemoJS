// Step 3: Introduction to Promises (Microtask)
console.log("Start");

Promise.resolve().then(() => {
  console.log("Promise");
});

console.log("End");