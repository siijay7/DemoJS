// Step 2: Introduction to setTimeout (Macrotask)
console.log("Start");

setTimeout(() => {
  console.log("Timeout");
}, 0);

console.log("End");