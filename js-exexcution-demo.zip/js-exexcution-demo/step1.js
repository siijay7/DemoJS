// Step 1: Understanding Synchronous Execution
console.log("A");
console.log("B");
console.log("C");